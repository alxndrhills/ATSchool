package ru.bellintegrator;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.support.PageFactory;
import ru.bellintegrator.page.factory.GoogleSearch;
import ru.bellintegrator.page.factory.OpenBankExchange;
import ru.bellintegrator.page.factory.OpenBankGoogleSearch;
import ru.bellintegrator.page.object.GoogleAfterSearch;
import ru.bellintegrator.page.object.GoogleBeforeSearch;

public class Tests extends TestBase {

    @Test
    public void findArticlePO() {
        driver.get("https://www.google.com/");
        GoogleBeforeSearch googleSearch = new GoogleBeforeSearch(driver, "q", "btnK");
        googleSearch.findArticles("Гладиолус");
        GoogleAfterSearch googleAfterSearch = new GoogleAfterSearch(driver, "q", "btnK", "//*[@class=\"TbwUpd NJjxre\"]//*[@class=\"eipWBe\"]");
        Assertions.assertTrue(googleAfterSearch.getArticles().stream().anyMatch(x -> x.getText().contains("Шпажник — Википедия")),
                "Статья не найдена");
    }

    @Test
    public void findArticlePF() {
        driver.get("https://www.google.com/");
        GoogleSearch googleSearch = PageFactory.initElements(driver, GoogleSearch.class);
        googleSearch.findArticles("Гладиолус");
        Assertions.assertTrue(googleSearch.getArticles().stream().anyMatch(x -> x.getText().contains("Шпажник — Википедия")),
                "Статья не найдена");
    }

    @Test
    public void findOpenBankLinkPF() {
        driver.get("https://www.google.com/");
        OpenBankGoogleSearch openBankGoogleSearch = PageFactory.initElements(driver, OpenBankGoogleSearch.class);
        openBankGoogleSearch.findLinks("Открытие");
        //Assertions.assertTrue(openBankGoogleSearch.getLinks().stream().anyMatch(x -> x.getText().contains("Банк «Открытие» — вклады, кредитные и дебетовые")),
        //        "Курс продажи не меньше курса покупки");
        OpenBankExchange openBankExchange = new OpenBankExchange(driver);
        Assertions.assertTrue(Double.valueOf(openBankExchange.getSellRate().toString()) < Double.valueOf(openBankExchange.getBuyRate().toString()), "Курс продажи не меньше курса покупки");
    }
}
