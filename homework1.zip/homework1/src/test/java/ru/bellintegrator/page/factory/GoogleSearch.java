package ru.bellintegrator.page.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.util.List;

public class GoogleSearch {

    private WebDriver driver;

    @FindBy(how = How.CLASS_NAME, className = "q")
    WebElement inputField;

    @FindBy(how = How.CLASS_NAME, className = "btnK")
    WebElement searchButton;

    @FindAll(@FindBy(how = How.XPATH, using = "//*[@class=\"TbwUpd NJjxre\"]//*[@class=\"eipWBe\"]"))
    List<WebElement> articles;

    public GoogleSearch(WebDriver driver) {
        this.driver = driver;
    }

    public void findArticles(String key) {
        inputField.click();
        inputField.sendKeys(key);
        searchButton.click();
    }

    public List<WebElement> getArticles() {
        return articles;
    }
}
