package ru.bellintegrator.page.object;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class GoogleAfterSearch extends GoogleBeforeSearch {

    List<WebElement> articles;

    public GoogleAfterSearch(WebDriver driver, String inputStr, String searchBtn, String xpathStr) {
        super(driver, inputStr, searchBtn);
        articles = driver.findElements(By.xpath(xpathStr));
        //System.out.println(articles.stream().toArray());
    }

    public List<WebElement> getArticles() {
        return this.articles;
    }
}
