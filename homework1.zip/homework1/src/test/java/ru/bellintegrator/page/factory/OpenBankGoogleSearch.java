package ru.bellintegrator.page.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.util.List;

public class OpenBankGoogleSearch {

    private WebDriver driver;

    @FindBy(how = How.CLASS_NAME, className = "q")
    WebElement inputField;

    @FindBy(how = How.CLASS_NAME, className = "btnK")
    WebElement searchButton;

    @FindAll(@FindBy(how = How.XPATH, using = "//*[@class=\"TbwUpd NJjxre\"]//*[@class=\"eipWBe\"]"))
    List<WebElement> links;

    public OpenBankGoogleSearch(WebDriver driver) {
        this.driver = driver;
    }

    public void findLinks(String key) {
        inputField.click();
        inputField.sendKeys(key);
        searchButton.click();
    }

    public List<WebElement> getLinks() {
        return links;
    }
}
