package ru.bellintegrator.page.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.util.List;

public class OpenBankExchange {

    private WebDriver driver;

    @FindBy(how = How.CLASS_NAME, className = "main-page-exchange__main")
    WebElement exchangeTable;

    @FindBy(how = How.CLASS_NAME, className = "main-page-exchange__main")
    WebElement buyRate;

    @FindBy(how = How.CLASS_NAME, className = "main-page-exchange__main")
    WebElement sellRate;

    public OpenBankExchange(WebDriver driver) {
        this.driver = driver;
    }

    public WebElement getBuyRate() {
        return buyRate;
    }

    public WebElement getSellRate() {
        return sellRate;
    }
}
