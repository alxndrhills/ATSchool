package ru.bellintegrator.page.object;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GoogleBeforeSearch {

    protected WebDriver driver;
    private WebElement inputField;
    private WebElement searchButton;

    public GoogleBeforeSearch(WebDriver driver, String inputStr, String searchBtn) {
        this.driver = driver;
        //this.inputField = driver.findElement(By.className("gLFyf gsfi"));
        this.inputField = driver.findElement(By.name(inputStr));
        //this.searchButton = driver.findElement(By.className("gNO89b"));
        this.searchButton = driver.findElement(By.name(searchBtn));
    }

    public void findArticles(String key) {
        inputField.click();
        inputField.sendKeys(key);
        searchButton.click();
    }
}
